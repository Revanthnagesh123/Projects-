<html>
    <head>
        <title>OFRS Project</title>
        <style>
             body
                            {
                                background-image:url('./opening-page/frs.jpg');
                                background-repeat:no-repeat;
                                background-size:cover;
                                /* background-position:center; */
                            }

        table
                            {
                                /* padding: 10px 10px; */
                                width: 400px;
                                /* border-radius:18px; */
                                /* position: relative;
                                 left: 400px;
                                 top: 70px; */
                            }
                            tr
                            {
                                background-color:black;
                                padding: 10px 10px;
                                border-radius:18px;
                                color:white;
                                /* position: relative;
                                 left: 400px;
                                 top: 70px; */
                                
                            }
                            </style>
</head>
<body bgcolor=lightblue>
    <!-- <img src="images/head1.png" alt="head1 image"><br><br> -->
<table width=100% align=left>







    <tr> <td width="50%">
    <form action="deletedept1.php" method="POST">
    <table width=80%  cellspacing=5 cellpadding=5>
     <tr> <td colspan=2>delete Staff </td> </tr>
<tr> <td>Staff Id</td> <td> <input type=text name=deletedept> </td></tr>    	



    
     <tr> <td> </td> <td> <input type=submit name=delete dept> </td></tr>
    </table>
    <!-- </td> <td width="50%"> <img src="images/pic1.png" style="width:60%;"> </td> </tr> -->
</form>
</table>
<!-- <table width=100%>
    <tr height=80><td></td></tr>
</table> -->

<!-- <img src="images/head2.png" alt="head2  image"> -->

</body>
</html>
