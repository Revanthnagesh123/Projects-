        <footer class="py-5 bg-dark">
            <div class="container px-4 px-lg-5"><p class="m-0 text-center text-white"> <?php echo $wtitle;?> <?php echo date('Y');?></p></div>
        </footer>