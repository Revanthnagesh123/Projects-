<html>
    <head>
        <title>OFRS Project</title>
        <style>
      *
      {
        text-decoration: none;
        list-style: none;
      }
      body
      {
        background-image:url('./opening-page/frs.jpg');
        background-repeat:no-repeat;
        background-size:cover;
        /* background-position:center; */
      }
      ul{
       
        display: flex;
        flex-direction: row;
        justify-content:start;
        
      }
      ul li{
       
        position: relative;
        top: 200px;
        margin-left: 10px;
        padding: 12px 20px;
        left: 535px;
        background-color: crimson;
        border-radius: 10px;
      }
      ul li a{
        color:black;
        /* text-transform: capital; */
        padding: 5px;
        font-weight:500;
        font-size: 18px;
      }
      


        </style>
</head>
<body bgcolor=lightblue>

<ul>
     <li> <a href=adddept.php>ADD STAFF.</a></li> 
     <li><a href=deletedept.php>DELETE STAFF. </a></li>

</ul>   



<!-- <img src="images/head2.png" alt="head2  image"> -->

</body>
</html>
