<?php

$conn=mysqli_connect('localhost','root','','ofrs');


?>